﻿global using Juga.Data;
global using Juga.Data.AuditProperties;
global using Juga.Data.Configuration;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.Extensions.Options;
global  using Juga.Abstractions.Data.AuditLog;