﻿global using ErrorOr;
global using Juga.CQRS.Abstractions;
global using AutoMapper;
global using FluentValidation;


